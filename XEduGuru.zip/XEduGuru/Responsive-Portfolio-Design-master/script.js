function toggleChatbot() {
    const chatbotPopup = document.getElementById('chatbot-popup');
    chatbotPopup.style.display = chatbotPopup.style.display === 'none' || chatbotPopup.style.display === '' ? 'block' : 'none';
}

function sendMessage() {
    const userInput = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');

    if (userInput.value.trim() !== "") {
        const userMessage = document.createElement('div');
        userMessage.className = 'message user-message';
        userMessage.textContent = userInput.value;
        chatBox.appendChild(userMessage);

        const botMessage = document.createElement('div');
        botMessage.className = 'message bot-message';
        botMessage.textContent = getBotResponse(userInput.value);
        chatBox.appendChild(botMessage);

        userInput.value = "";
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

function getBotResponse(input) {
    // Simple hardcoded responses
    const responses = {
        "hi": "Hello! How can I assist you today?",
        "hello": "Hi there! What can I do for you?",
        "how are you": "I'm just a bunch of code, but I'm here to help you!",
        "bye": "Goodbye! Have a great day!"
    };

    return responses[input.toLowerCase()] || "I'm sorry, I don't understand that.";
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}